package edu.cscc;
import org.junit.Test;

import static  org.junit.Assert.assertTrue;

public class RPSLSpock_Test {

    @Test
    public void isValidPick(){

    RPSLSpock Bam = new RPSLSpock();

        assertTrue(Bam.isValidPick("rock") == true);
        assertTrue(Bam.isValidPick("paper") == true);
        assertTrue(Bam.isValidPick("scissors") == true);
        assertTrue(Bam.isValidPick("lizard") == true);
        assertTrue(Bam.isValidPick("spock") == true);
        assertTrue(Bam.isValidPick("book") == false);

        assertTrue(Bam.isValidPick(Bam.generatePick()) == true);
    }

    @Test
    public  void generatePick() {
       RPSLSpock Bam = new RPSLSpock();
       for (int counter = 0; counter < 1000000; counter++) {
           assertTrue(Bam.isValidPick(Bam.generatePick()) == true);

       }
   }
  @Test
   public void isComputerWin() {
    RPSLSpock Bam = new RPSLSpock();

       // assertTrue( Bam.isComputerWin("ROCK", "SCISSORS") == true);
        assertTrue( Bam.isComputerWin("ROCK", "LIZARD") == true);
       /* assertTrue( Bam.isComputerWin("PAPER", "ROCK") == true);
        assertTrue( Bam.isComputerWin("PAPER", "SPOCK") == true);
        assertTrue( Bam.isComputerWin("SCISSORS", "PAPER") == true);
        assertTrue( Bam.isComputerWin("SCISSORS", "LIZARD") == true);
        assertTrue( Bam.isComputerWin("LIZARD", "PAPER") == true);
        assertTrue( Bam.isComputerWin("LIZARD", "SPOCK") == true);
        assertTrue( Bam.isComputerWin("SPOCK", "SCISSORS") == true);
        assertTrue( Bam.isComputerWin("SPOCK", "ROCK") == true);
        assertTrue( Bam.isComputerWin("ROCK", "PAPER") == false);*/

    }
}